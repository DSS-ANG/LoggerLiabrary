﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LoggerLiabraryDevonCodeTest
{
    
    public class DllMessageLog
    {
        //private work variables
        private StringBuilder _msg = new StringBuilder();

        private bool _retainFocus = true;
        private bool _showDatetime = false;
        private MessageLogForm _messageLogForm = new MessageLogForm();
        private string _caption = "Message Log";
        private string _font = "Lucida Console";
        private float _fontSize = (float)10.0;
        private bool _changeFont = false;

        public DllMessageLog()
        {
            _messageLogForm.WindowState = FormWindowState.Normal;
            _messageLogForm.Text = _caption;
            _messageLogForm.txtMessageLog.Text = "";
            ChangeMessageLogFont();

            _messageLogForm.Left = 0;
            int y = SystemInformation.VirtualScreen.Height - _messageLogForm.Size.Height - 100;
            _messageLogForm.Top = y;


            _messageLogForm.Show();
        }

        public bool AllowFileErase
        {
            get
            {
                return _messageLogForm.AllowFileErase;
            }
            set
            {
                _messageLogForm.AllowFileErase = value;
            }
        }

        public string Caption
        {
            get
            {
                return _caption;
            }
            set
            {
                _caption = value;
                _messageLogForm.Text = value;
            }
        }

        public Form Form
        {
            get
            {
                return _messageLogForm;
            }
        }

        public bool FormIsVisible
        {
            get
            {
                return _messageLogForm.Visible;
            }
        }

        public bool RetainFocus
        {
            get
            {
                return _retainFocus;
            }
            set
            {
                _retainFocus = value;
            }
        }

        public bool ShowDatetime
        {
            get
            {
                return _showDatetime;
            }
            set
            {
                _showDatetime = value;
            }
        }

        public string Font
        {
            get
            {
                return _font;
            }
            set
            {
                _font = value;
                _changeFont = true;
            }
        }

        public float FontSize
        {
            get
            {
                return _fontSize;
            }
            set
            {
                _fontSize = value;
                _changeFont = true;
            }
        }

        public void Clear()
        {
            _messageLogForm.txtMessageLog.Clear();
        }

        public void CloseWindow()
        {
            _messageLogForm.Close();
        }

        public void Focus()
        {
            _messageLogForm.Focus();
        }

        public void HideWindow()
        {
            _messageLogForm.Hide();
        }

        public void LoadFile(string filename)
        {
            _messageLogForm.txtMessageLog.LoadFile(filename, RichTextBoxStreamType.PlainText);
        }

        public void SaveFile(string filename)
        {
            _messageLogForm.txtMessageLog.SaveFile(filename, RichTextBoxStreamType.PlainText);
        }

        public void ShowWindow()
        {
            _messageLogForm.Show();
        }

        public void WriteLine(string message)
        {
            string text;
            string text2 = message.Replace("\0", " ");

            if (_changeFont)
            {
                ChangeMessageLogFont();
            }

            if (_showDatetime)
            {
                text = DateTime.Now.ToString("yyy/MM/dd hh:mm:ss ");
            }
            else
            {
                text = "";
            }
            _messageLogForm.txtMessageLog.Select(_messageLogForm.txtMessageLog.Text.Length, 1);
            _messageLogForm.txtMessageLog.SelectedText = text + text2 + "\r\n";
            if (RetainFocus)
            {
                Application.DoEvents();
                _messageLogForm.Focus();
            }
        }

        private void ChangeMessageLogFont()
        {
            _messageLogForm.txtMessageLog.Font = new System.Drawing.Font(_font, _fontSize);
            _changeFont = false;
        }
    }
}
