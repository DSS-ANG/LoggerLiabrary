using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace LoggerLiabraryDevonCodeTest
{

    public class MessageLog
    {
        // Fields
        private bool _retainFocus = true;
        private bool _showDatetime = false;
        private MessageLogForm _messageLogForm = new MessageLogForm();
        private string _caption = "Message Log";
        private string _font = "Microsoft Sans Serif";
        private float _fontSize = (float)8.25;
        private bool _changeFont = false;

        public MessageLog()
        {
            MessageLogForm messageLogForm = this._messageLogForm;
            messageLogForm.WindowState = FormWindowState.Normal;
            messageLogForm.Text = this._caption;
            messageLogForm.txtMessageLog.Text = "";
            //messageLogForm.txtMessageLog.Font = new System.Drawing.Font(_font, _fontSize);
            ChangeMessageLogFont();
            messageLogForm.Hide();
            messageLogForm = null;
        }

        public bool AllowFileErase
        {
            get
            {
                return this._messageLogForm.AllowFileErase;
            }
            set
            {
                this._messageLogForm.AllowFileErase = value;
            }
        }


        public string Caption
        {
            get
            {
                return this._caption;
            }
            set
            {
                this._caption = value;
                this._messageLogForm.Text = value;
            }
        }

        public Form Form
        {
            get
            {
                return this._messageLogForm;
            }
        }

        public bool FormIsVisible
        {
            get
            {
                return this._messageLogForm.Visible;
            }
        }

        public bool RetainFocus
        {
            get
            {
                return this._retainFocus;
            }
            set
            {
                this._retainFocus = value;
            }
        }

        public bool ShowDatetime
        {
            get
            {
                return this._showDatetime;
            }
            set
            {
                this._showDatetime = value;
            }
        }

        public string Font
        {
            get
            {
                return this._font;
            }
            set
            {
                this._font = value;
                _changeFont = true;
            }
        }

        public float FontSize
        {
            get
            {
                return this._fontSize;
            }
            set
            {
                this._fontSize = value;
                _changeFont = true;
            }
        }

        public void Clear()
        {
            this._messageLogForm.txtMessageLog.Clear();
        }

        public void CloseWindow()
        {
            this._messageLogForm.Close();
        }

        public void Focus()
        {
            this._messageLogForm.Focus();
        }

        public void HideWindow()
        {
            this._messageLogForm.Hide();
        }

        public void LoadFile(string filename)
        {
            this._messageLogForm.txtMessageLog.LoadFile(filename, RichTextBoxStreamType.PlainText);
        }

        public void SaveFile(string filename)
        {
            this._messageLogForm.txtMessageLog.SaveFile(filename, RichTextBoxStreamType.PlainText);
        }

        public void ShowWindow()
        {
            this._messageLogForm.Show();
        }

        public void WriteLine(string message)
        {
            string text;
            string text2 = message.Replace("\0", " ");

            if (_changeFont)
            {
                ChangeMessageLogFont();
            }

            if (this._showDatetime)
            {
                text = DateTime.Now.ToString("yyy/MM/dd hh:mm:ss ");
            }
            else
            {
                text = " ";
            }
            this._messageLogForm.txtMessageLog.Select(this._messageLogForm.txtMessageLog.Text.Length, 0);
            this._messageLogForm.txtMessageLog.SelectedText = text + text2 + "\r\n";
            this._messageLogForm.txtMessageLog.SelectionStart = this._messageLogForm.txtMessageLog.Text.Length;
            this._messageLogForm.txtMessageLog.ScrollToCaret();
            if (this.RetainFocus)
            {
                Application.DoEvents();
                this._messageLogForm.Focus();
            }
        }

        private void ChangeMessageLogFont()
        {
            this._messageLogForm.txtMessageLog.Font = new System.Drawing.Font(_font, _fontSize);
            _changeFont = false;
        }

    }

}
