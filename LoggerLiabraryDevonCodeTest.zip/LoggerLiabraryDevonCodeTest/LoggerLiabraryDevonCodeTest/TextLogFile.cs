using System;
using System.IO;
using System.Collections.Generic;
using System.Text;

namespace LoggerLiabraryDevonCodeTest
{
    /// <summary>
    /// Class for routines to write messages to a text log file. No User Interface output window is provided by this class.
    /// </summary>
    public class TextLogFile
    {
        // Fields
        private bool _showDatetime;
        private bool _showMessageType = false;         //Show message type on line
        private bool _showErrorWarningTypes = false;   //Only show error and warning messages
        private string _applicationName;
        private string _dateTimeFormat;
        private string _fileName;
        private string _machineName;

        public enum LogMessageType
        {
#pragma warning disable 1591
            Error = 1,
            Warning = 2,
            Information = 4,
#pragma warning restore 1591
        }

        public TextLogFile()
        {
            this._showDatetime = false;
            this._showMessageType = false;
            this._fileName = "";
            this._applicationName = "";
            this._machineName = "";
            this._dateTimeFormat = "MM/dd/yyyy HH:mm:ss";
            string text = (Environment.CurrentDirectory + @"\applog.txt").Replace(@"\\", @"\");
            this._fileName = text;
        }

        public TextLogFile(string fileName)
        {
            this._showDatetime = false;
            this._fileName = "";
            this._applicationName = "";
            this._machineName = "";
            this._dateTimeFormat = "MM/dd/yyyy HH:mm:ss";
            this._fileName = fileName;
        }

        public void TruncateFile()
        {
            if (File.Exists(this.FileName))
            {
                FileStream fs = new FileStream(this.FileName, FileMode.Truncate);
                fs.Close();
            }
        }

        public void WriteLine(string message)
        {
            WriteLine(message, LogMessageType.Information);
        }

        public void WriteLine(string message, LogMessageType logMessageType)
        {
            string messageDateAndType = "";
            string formattedMessage = "";
            string messagePrefix = "";
            string machineName = "";
            try
            {
                if (this._showDatetime)
                {
                    messageDateAndType = DateTime.Now.ToString(this._dateTimeFormat);
                }
                else
                {
                    messageDateAndType = "";
                }

                if (this._showMessageType)
                {
                    if (messageDateAndType.Length > 0)
                        messageDateAndType += " ";
                    messageDateAndType += logMessageType.ToString().ToUpper() + ": ";
                }

                if (this.ShowErrorWarningTypes == true && this.ShowMessageType == false)
                {
                    if (logMessageType == LogMessageType.Warning || logMessageType == LogMessageType.Error)
                    {
                        if (messageDateAndType.Length > 0)
                            messageDateAndType += " ";
                        messageDateAndType += logMessageType.ToString().ToUpper() + ": ";
                    }
                }


                if (this._machineName.Length > 0)
                {
                    if (this._applicationName.Length > 0)
                    {
                        machineName = " on " + this._machineName;
                    }
                    else
                    {
                        machineName = this._machineName;
                    }
                }
                else
                {
                    machineName = "";
                }
                if ((this._applicationName.Length > 0) | (machineName.Length > 0))
                {
                    messagePrefix = (messageDateAndType + " <" + (this._applicationName + machineName).Trim() + "> ").Trim();
                }
                else
                {
                    messagePrefix = messageDateAndType.Trim();
                }
                if (messagePrefix.Length > 0)
                {
                    formattedMessage = messagePrefix + " " + message;
                }
                else
                {
                    formattedMessage = message;
                }
                StreamWriter writer = File.AppendText(this._fileName);
                writer.WriteLine(formattedMessage);
                writer.Flush();
                writer.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void WriteBlankLine()
        {
            try
            {
                StreamWriter writer = File.AppendText(this._fileName);
                writer.WriteLine(string.Empty);
                writer.Flush();
                writer.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public string ApplicationName
        {
            get
            {
                return this._applicationName;
            }
            set
            {
                this._applicationName = value;
            }
        }

        public string DateTimeFormat
        {
            get
            {
                return this._dateTimeFormat;
            }
            set
            {
                this._dateTimeFormat = value;
            }
        }
        public string FileName
        {
            get
            {
                return this._fileName;
            }
            set
            {
                this._fileName = value;
            }
        }

        public string MachineName
        {
            get
            {
                return this._machineName;
            }
            set
            {
                this._machineName = value;
            }
        }

        public bool ShowDatetime
        {
            get
            {
                return this._showDatetime;
            }
            set
            {
                this._showDatetime = value;
            }
        }

        public bool ShowMessageType
        {
            get
            {
                return this._showMessageType;
            }
            set
            {
                this._showMessageType = value;
            }
        }

        public bool ShowErrorWarningTypes
        {
            get
            {
                return this._showErrorWarningTypes;
            }
            set
            {
                this._showErrorWarningTypes = value;
            }
        }



    }
}
