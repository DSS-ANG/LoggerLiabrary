﻿//****************************************************************************************************
//
// Copyright © ProFast Computing 2012-2015
//
//****************************************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;

namespace GlobalObjects
{
    public class CustomAppConfig
    {
        private StringBuilder _msg = new StringBuilder();
        private string _pathToConfigFile = string.Empty;
        private ExeConfigurationFileMap _configMap = null;
        private Configuration _config = null;

        public CustomAppConfig(string pathToConfigFile)
        {
            _pathToConfigFile = pathToConfigFile;
            _configMap = new ExeConfigurationFileMap();
            _configMap.ExeConfigFilename = pathToConfigFile;
            _config = ConfigurationManager.OpenMappedExeConfiguration(_configMap, ConfigurationUserLevel.None);
        }

        public static bool CreateCustomConfigFile(string customConfigFilePath, bool overwriteExistingFile)
        {
            bool fileCreated = false;
            StringBuilder defaultCustomConfigFile = new StringBuilder();
            StringBuilder errMsg = new StringBuilder();

            try
            {
                defaultCustomConfigFile.Length = 0;
                defaultCustomConfigFile.Append("<?xml version=\"1.0\"?>");
                defaultCustomConfigFile.Append(Environment.NewLine);
                defaultCustomConfigFile.Append("<configuration>");
                defaultCustomConfigFile.Append(Environment.NewLine);
                defaultCustomConfigFile.Append("  <appSettings>");
                defaultCustomConfigFile.Append(Environment.NewLine);
                defaultCustomConfigFile.Append("    <add key=\"DefaultSetting\" value=\"\" />");
                defaultCustomConfigFile.Append(Environment.NewLine);
                defaultCustomConfigFile.Append("  </appSettings>");
                defaultCustomConfigFile.Append(Environment.NewLine);
                defaultCustomConfigFile.Append("</configuration>");

                if (File.Exists(customConfigFilePath))
                    if (overwriteExistingFile)
                        File.Delete(customConfigFilePath);
                    else
                    {
                        errMsg.Length = 0;
                        errMsg.Append("File with same name already exists and overwrite set to false:  ");
                        errMsg.Append(customConfigFilePath);
                        throw new System.Exception(errMsg.ToString());
                    }
                else
                {
                    ;
                }
                FileStream fs = File.Create(customConfigFilePath);
                fs.Close();
                File.WriteAllText(customConfigFilePath, defaultCustomConfigFile.ToString());

                fileCreated = true;
            }
            catch (System.Exception ex)
            {
                fileCreated = false;
                errMsg.Length = 0;
                errMsg.Append("Attempt to create custom config file failed. File name: ");
                errMsg.Append(customConfigFilePath);
                errMsg.Append(Environment.NewLine);
                errMsg.Append(GlobalObjects.AppMessages.FormatErrorMessage(ex));
                throw new System.Exception(errMsg.ToString());
            }

            return fileCreated;
        }

        public string GetConfigValue(string psKey)
        {
            string sConfigValue = string.Empty;
            try
            {
                sConfigValue = string.Empty;
                sConfigValue = _config.AppSettings.Settings[psKey].Value;
            }
            catch
            {
                sConfigValue = string.Empty;
            }

            if (sConfigValue == null)
                sConfigValue = string.Empty;

            return sConfigValue;

        }

        public string GetStringValueFromConfigFile(string psKey)
        {
            return GetStringValueFromConfigFile(psKey, string.Empty);
        }

        public string GetStringValueFromConfigFile(string psKey, string psDefaultValue)
        {
            string sKey = psKey;
            if (sKey == null)
                sKey = string.Empty;
            string sConfigValue = GetConfigValue(sKey);
            if (sConfigValue.Length == 0)
                sConfigValue = psDefaultValue;
            return sConfigValue;
        }

        public bool GetBooleanValueFromConfigFile(string psKey)
        {
            return GetBooleanValueFromConfigFile(psKey, "false");
        }

        public bool GetBooleanValueFromConfigFile(string psKey, string psDefaultValue)
        {
            string sKey = psKey;
            if (sKey == null)
                sKey = string.Empty;
            bool bConfigValue = true;
            string sConfigValue = GetConfigValue(psKey);
            if (sConfigValue.Length == 0)
                sConfigValue = "False";
            bConfigValue = AppTextGlobals.ConvertStringToBoolean(sConfigValue, psDefaultValue);
            return bConfigValue;
        }

        public int GetIntValueFromConfigFile(string psKey)
        {
            return GetIntValueFromConfigFile(psKey, 0);
        }

        public int GetIntValueFromConfigFile(string psKey, int pnDefaultValue)
        {
            string sKey = psKey;
            if (sKey == null)
                sKey = string.Empty;
            int nConfigValue = 0;
            string sConfigValue = GetConfigValue(psKey);
            nConfigValue = AppTextGlobals.ConvertStringToInt(sConfigValue, pnDefaultValue);
            return nConfigValue;
        }

        public long GetLongValueFromConfigFile(string psKey)
        {
            return GetLongValueFromConfigFile(psKey, 0);
        }

        public long GetLongValueFromConfigFile(string psKey, long pnDefaultValue)
        {
            string sKey = psKey;
            if (sKey == null)
                sKey = string.Empty;
            long nConfigValue = 0;
            string sConfigValue = GetConfigValue(psKey);
            nConfigValue = AppTextGlobals.ConvertStringToLong(sConfigValue, pnDefaultValue);
            return nConfigValue;
        }

        public float GetFloatValueFromConfigFile(string psKey)
        {
            return GetFloatValueFromConfigFile(psKey, (float)0.0);
        }

        public float GetFloatValueFromConfigFile(string psKey, float pnDefaultValue)
        {
            string sKey = psKey;
            if (sKey == null)
                sKey = string.Empty;
            float nConfigValue = (float)0.0;
            string sConfigValue = GetConfigValue(psKey);
            nConfigValue = AppTextGlobals.ConvertStringToFloat(sConfigValue, pnDefaultValue);
            return nConfigValue;
        }

        public double GetDoubleValueFromConfigFile(string psKey)
        {
            return GetDoubleValueFromConfigFile(psKey, (double)0.0);
        }

        public double GetDoubleValueFromConfigFile(string psKey, double pnDefaultValue)
        {
            string sKey = psKey;
            if (sKey == null)
                sKey = string.Empty;
            double nConfigValue = (double)0.0;
            string sConfigValue = GetConfigValue(psKey);
            nConfigValue = AppTextGlobals.ConvertStringToDouble(sConfigValue, pnDefaultValue);
            return nConfigValue;
        }

        public KeyValueConfigurationCollection GetAllAppSettings()
        {

            AppSettingsSection oAppSettingsSection = _config.AppSettings;
            KeyValueConfigurationCollection oAppSettings = oAppSettingsSection.Settings;

            return oAppSettings;
        }

        public KeyValueConfigurationCollection GetAllAppSettings(string psExecutableFilePath)
        {
            if (File.Exists(psExecutableFilePath) == false)
                return null;

            Configuration config
                = ConfigurationManager.OpenExeConfiguration(psExecutableFilePath);

            AppSettingsSection oAppSettingsSection = config.AppSettings;
            KeyValueConfigurationCollection oAppSettings = oAppSettingsSection.Settings;

            return oAppSettings;
        }

        public void SetConfigValue(KeyValuePair<string, string> configElement)
        {

            if (_config.AppSettings.Settings[configElement.Key] != null)
                _config.AppSettings.Settings[configElement.Key].Value = configElement.Value;
            else
                _config.AppSettings.Settings.Add(configElement.Key, configElement.Value);

            _config.Save(ConfigurationSaveMode.Modified);
        }
        public void SetConfigValue(KeyValuePair<string, string>[] configElements)
        {
            if (configElements.Length > 0)
            {
                for (int i = 0; i < configElements.Length; i++)
                {
                    if (_config.AppSettings.Settings[configElements[i].Key] != null)
                        _config.AppSettings.Settings[configElements[i].Key].Value = configElements[i].Value;
                    else
                        _config.AppSettings.Settings.Add(configElements[i].Key, configElements[i].Value);
                }
            }

            _config.Save(ConfigurationSaveMode.Modified);

        }

        public void SetConfigValue(List<KeyValuePair<string, string>> configElements)
        {

            if (configElements.Count > 0)
            {
                for (int i = 0; i < configElements.Count; i++)
                {
                    if (_config.AppSettings.Settings[configElements[i].Key] != null)
                        _config.AppSettings.Settings[configElements[i].Key].Value = configElements[i].Value;
                    else
                        _config.AppSettings.Settings.Add(configElements[i].Key, configElements[i].Value);
                }
            }

            _config.Save(ConfigurationSaveMode.Modified);

        }

    }

}
