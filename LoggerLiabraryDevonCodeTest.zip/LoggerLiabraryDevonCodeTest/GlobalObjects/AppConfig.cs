using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Configuration;
using System.IO;

namespace GlobalObjects
{
    public class AppConfig
    {
        static public string GetConfigValue(string psKey)
        {
            string sConfigValue = string.Empty;
            try
            {
                sConfigValue = string.Empty;
                sConfigValue = System.Configuration.ConfigurationManager.AppSettings[psKey];
            }
            catch
            {
                sConfigValue = string.Empty;
            }

            if (sConfigValue == null)
                sConfigValue = string.Empty;

            return sConfigValue;

        }
        static public string GetStringValueFromConfigFile(string psKey)
        {
            return GetStringValueFromConfigFile(psKey, string.Empty);
        }
        static public string GetStringValueFromConfigFile(string psKey, string psDefaultValue)
        {
            string sKey = psKey;
            if (sKey == null)
                sKey = string.Empty;
            string sConfigValue = GetConfigValue(sKey);
            if (sConfigValue.Length == 0)
                sConfigValue = psDefaultValue;
            return sConfigValue;
        }
        static public bool GetBooleanValueFromConfigFile(string psKey)
        {
            return GetBooleanValueFromConfigFile(psKey, "false");
        }
        static public bool GetBooleanValueFromConfigFile(string psKey, string psDefaultValue)
        {
            string sKey = psKey;
            if (sKey == null)
                sKey = string.Empty;
            bool bConfigValue = true;
            string sConfigValue = GetConfigValue(psKey);
            if (sConfigValue.Length == 0)
                sConfigValue = psDefaultValue;
            bConfigValue = AppTextGlobals.ConvertStringToBoolean(sConfigValue, psDefaultValue);
            return bConfigValue;
        }
        static public int GetIntValueFromConfigFile(string psKey)
        {
            return GetIntValueFromConfigFile(psKey, 0);
        }
        static public int GetIntValueFromConfigFile(string psKey, int pnDefaultValue)
        {
            string sKey = psKey;
            if (sKey == null)
                sKey = string.Empty;
            int nConfigValue = 0;
            string sConfigValue = GetConfigValue(psKey);
            nConfigValue = AppTextGlobals.ConvertStringToInt(sConfigValue, pnDefaultValue);
            return nConfigValue;
        }
        static public long GetLongValueFromConfigFile(string psKey)
        {
            return GetLongValueFromConfigFile(psKey, 0);
        }
        static public long GetLongValueFromConfigFile(string psKey, long pnDefaultValue)
        {
            string sKey = psKey;
            if (sKey == null)
                sKey = string.Empty;
            long nConfigValue = 0;
            string sConfigValue = GetConfigValue(psKey);
            nConfigValue = AppTextGlobals.ConvertStringToLong(sConfigValue, pnDefaultValue);
            return nConfigValue;
        }
        static public float GetFloatValueFromConfigFile(string psKey)
        {
            return GetFloatValueFromConfigFile(psKey, (float)0.0);
        }
        static public float GetFloatValueFromConfigFile(string psKey, float pnDefaultValue)
        {
            string sKey = psKey;
            if (sKey == null)
                sKey = string.Empty;
            float nConfigValue = (float)0.0;
            string sConfigValue = GetConfigValue(psKey);
            nConfigValue = AppTextGlobals.ConvertStringToFloat(sConfigValue, pnDefaultValue);
            return nConfigValue;
        }
        static public double GetDoubleValueFromConfigFile(string psKey)
        {
            return GetDoubleValueFromConfigFile(psKey, (double)0.0);
        }
        static public double GetDoubleValueFromConfigFile(string psKey, double pnDefaultValue)
        {
            string sKey = psKey;
            if (sKey == null)
                sKey = string.Empty;
            double nConfigValue = (double)0.0;
            string sConfigValue = GetConfigValue(psKey);
            nConfigValue = AppTextGlobals.ConvertStringToDouble(sConfigValue, pnDefaultValue);
            return nConfigValue;
        }

        static public KeyValueConfigurationCollection GetAllAppSettings()
        {
            Configuration config
                = ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

            AppSettingsSection oAppSettingsSection = config.AppSettings;
            KeyValueConfigurationCollection oAppSettings = oAppSettingsSection.Settings;

            return oAppSettings;
        }

        static public KeyValueConfigurationCollection GetAllAppSettings(string psExecutableFilePath)
        {
            if (File.Exists(psExecutableFilePath) == false)
                return null;

            Configuration config
                = ConfigurationManager.OpenExeConfiguration(psExecutableFilePath);

            AppSettingsSection oAppSettingsSection = config.AppSettings;
            KeyValueConfigurationCollection oAppSettings = oAppSettingsSection.Settings;

            return oAppSettings;
        }
        static public void SetConfigValue (KeyValuePair<string, string> configElement)
        {
            Configuration config
                = ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

            if(config.AppSettings.Settings[configElement.Key] != null)
                config.AppSettings.Settings[configElement.Key].Value = configElement.Value;
            else
                config.AppSettings.Settings.Add(configElement.Key, configElement.Value);


            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");
        }

        static public void SetConfigValue(KeyValuePair<string, string>[] configElements)
        {
            Configuration config
                = ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

            //config.AppSettings.Settings.Add(configKeyVal);
            if (configElements.Length > 0)
            {
                for (int i = 0; i < configElements.Length; i++)
                {
                    if (config.AppSettings.Settings[configElements[i].Key] != null)
                        config.AppSettings.Settings[configElements[i].Key].Value = configElements[i].Value;
                    else
                        config.AppSettings.Settings.Add(configElements[i].Key, configElements[i].Value);
                }
            }

            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

        }
        static public void SetConfigValue(List<KeyValuePair<string, string>> configElements)
        {
            Configuration config
                = ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);
            if (configElements.Count > 0)
            {
                for (int i = 0; i < configElements.Count; i++)
                {
                    if (config.AppSettings.Settings[configElements[i].Key] != null)
                        config.AppSettings.Settings[configElements[i].Key].Value = configElements[i].Value;
                    else
                        config.AppSettings.Settings.Add(configElements[i].Key, configElements[i].Value);
                }
            }

            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

        }

    }
}
