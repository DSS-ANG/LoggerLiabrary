﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GlobalObjects
{

    public class ModelessPopupDialog
    {
        //private work variables
        private StringBuilder _msg = new StringBuilder();

        //private variables for properties
        private ModelessPopupDialogForm _frm = null;
        private string _message = string.Empty;
        private string _buttonLabel = string.Empty;
        private int _maxSecondsToDisplayPopup = 0;

        public ModelessPopupDialog()
        {
            InitInstance((int)0);
        }

        public ModelessPopupDialog(int maxSecondsToDisplayPopup)
        {
            InitInstance(maxSecondsToDisplayPopup);
        }

        private void InitInstance(int maxSecondsToDisplayPopup)
        {
            _maxSecondsToDisplayPopup = maxSecondsToDisplayPopup;
            if (_maxSecondsToDisplayPopup > 0)
                _frm = new ModelessPopupDialogForm(_maxSecondsToDisplayPopup);
            else
                _frm = new ModelessPopupDialogForm();
        }

        
        public int MaxSecondsToDisplayPopup
        {
            get
            {
                return _maxSecondsToDisplayPopup;
            }
            set
            {
                _maxSecondsToDisplayPopup = value;
            }
        }

        public ModelessPopupDialogForm Frm
        {
            get
            {
                return _frm;
            }
        }

        public string Message
        {
            get
            {
                return _frm.MessageText;
            }
            set
            {
                _frm.MessageText = value;
            }
        }

        public string ButtonLabel
        {
            get
            {
                return _buttonLabel;
            }
            set
            {
                _buttonLabel = value;
            }
        }

        public bool IsVisible
        {
            get
            {
                return _frm.Visible;
            }
            set
            {
                _frm.Visible = value;
            }
        }

        public bool ActionButtonPressed
        {
            get
            {
                return _frm.ActionButtonPressed;
            }
            set
            {
                _frm.ActionButtonPressed = value;
            }
        }

        public void Show()
        {
            _frm.Show();
        }

        public void Show(string messageToShow)
        {
            _frm.MessageText = messageToShow;
            //_frm.Show();
            this.Show();
        }

        public void Show(string messageToShow, string buttonLabel)
        {
            _frm.MessageText = messageToShow;
            _frm.ButtonText = buttonLabel;
            //_frm.Show();
            this.Show();
        }

        public void Close()
        {
            _frm.Close();
        }

        public void SetFocusToPopup()
        {
            _frm.SetFocusToActionButton();
        }


    }
}
