using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Globalization;

namespace GlobalObjects
{

    public class AppInfo
    {
        // Fields
        private static Assembly _asm = Assembly.GetEntryAssembly();
        private static AssemblyCompanyAttribute _companyAttribute;
        private static AssemblyCopyrightAttribute _copyrightAttribute;
        private static AssemblyDescriptionAttribute _descriptionAttribute;
        private static AssemblyProductAttribute _productAttribute;
        private static AssemblyTitleAttribute _titleAttribute;
        private static AssemblyTrademarkAttribute _trademarkAttribute;

        public static string AssemblyCompany
        {
            get
            {
                _companyAttribute = (AssemblyCompanyAttribute)_asm.GetCustomAttributes(typeof(AssemblyCompanyAttribute), false)[0];
                return _companyAttribute.Company;
            }
        }
        public static string AssemblyCopyright
        {
            get
            {
                _copyrightAttribute = (AssemblyCopyrightAttribute)_asm.GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false)[0];
                return _copyrightAttribute.Copyright;
            }
        }

        public static string AssemblyCulture
        {
            get
            {
                return CultureInfo.CurrentCulture.ToString();
            }
        }

        public static string AssemblyDescription
        {
            get
            {
                _descriptionAttribute = (AssemblyDescriptionAttribute)_asm.GetCustomAttributes(typeof(AssemblyDescriptionAttribute), false)[0];
                return _descriptionAttribute.Description;
            }
        }

        public static string AssemblyName
        {
            get
            {
                return Assembly.GetEntryAssembly().GetName().Name;
            }
        }

        public static string AssemblyProduct
        {
            get
            {
                _productAttribute = (AssemblyProductAttribute)_asm.GetCustomAttributes(typeof(AssemblyProductAttribute), false)[0];
                return _productAttribute.Product;
            }
        }

        public static string AssemblyTitle
        {
            get
            {
                _titleAttribute = (AssemblyTitleAttribute)_asm.GetCustomAttributes(typeof(AssemblyTitleAttribute), false)[0];
                return _titleAttribute.Title;
            }
        }
        public static string AssemblyTrademark
        {
            get
            {
                _trademarkAttribute = (AssemblyTrademarkAttribute)_asm.GetCustomAttributes(typeof(AssemblyTrademarkAttribute), false)[0];
                return _trademarkAttribute.Trademark;
            }
        }

        public static string AssemblyVersion
        {
            get
            {
                return Assembly.GetEntryAssembly().GetName().Version.ToString();
            }
        }

        public static Version AssemblyVersionEx
        {
            get
            {
                return Assembly.GetEntryAssembly().GetName().Version;
            }
        }

        public static string CurrentExecutingAssemblyDirectory
        {
            get
            {
                return System.IO.Path.GetDirectoryName(new Uri(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).LocalPath);
            }
        }

        public static string CurrentExecutingAssembly
        {
            get
            {
                return new Uri(System.Reflection.Assembly.GetExecutingAssembly().CodeBase).LocalPath;
            }
        }

        public static string CurrentEntryAssemblyDirectory
        {
            get
            {
                return System.IO.Path.GetDirectoryName(new Uri(System.Reflection.Assembly.GetEntryAssembly().CodeBase).LocalPath);
            }
        }

        public static string CurrentEntryAssembly
        {
            get
            {
                return new Uri(System.Reflection.Assembly.GetEntryAssembly().CodeBase).LocalPath;
            }
        }
    }
}
