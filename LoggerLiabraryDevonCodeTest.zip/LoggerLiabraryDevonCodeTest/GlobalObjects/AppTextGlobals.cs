﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GlobalObjects
{

    public class AppTextGlobals
    {
        public static bool ConvertYesNoToTrueFalse(string psYesNo)
        {
            bool bTrueFalse = false;
            switch (psYesNo.ToLower())
            {
                case "yes":
                    bTrueFalse = true;
                    break;
                case "true":
                    bTrueFalse = true;
                    break;
                default:
                    bTrueFalse = false;
                    break;
            }
            return bTrueFalse;
        }

        public static bool ConvertStringToBoolean(string psValue)
        {

            return ConvertStringToBoolean(psValue, "False");

        }

        public static bool ConvertStringToBoolean(string psValue, string psDefaultValue)
        {
            bool bValue = false;
            bool bDefaultValue = false;

            if (psDefaultValue != null)
            {
                if (psDefaultValue.ToUpper() == "TRUE")
                {
                    bDefaultValue = true;
                }
                else
                {
                    bDefaultValue = false;
                }
            }

            switch (psValue.ToLower())
            {
                case "true":
                    bValue = true;
                    break;
                case "yes":
                    bValue = true;
                    break;
                case "false":
                    bValue = false;
                    break;
                case "no":
                    bValue = false;
                    break;
                default:
                    bValue = bDefaultValue;
                    break;
            }

            return bValue;
        }

        public static int ConvertStringToInt(string psValue)
        {
            return ConvertStringToInt(psValue, 0);
        }

        public static int ConvertStringToInt(string psValue, int pnDefaultValue)
        {
            int nValue = 0;
            try
            {
                nValue = Convert.ToInt32(psValue);
            }
            catch
            {
                nValue = pnDefaultValue;
            }

            return nValue;
        }

        public static long ConvertStringToLong(string psValue)
        {
            return ConvertStringToLong(psValue, 0);
        }

        public static long ConvertStringToLong(string psValue, long pnDefaultValue)
        {
            long nValue = 0;
            try
            {
                nValue = Convert.ToInt64(psValue);
            }
            catch
            {
                nValue = pnDefaultValue;
            }
            return nValue;
        }

        public static float ConvertStringToFloat(string psValue)
        {
            return ConvertStringToFloat(psValue, (float)0.0);
        }

        public static float ConvertStringToFloat(string psValue, float pnDefaultValue)
        {
            float nValue = (float)0.0;
            try
            {
                nValue = Convert.ToSingle(psValue);
            }
            catch
            {
                nValue = pnDefaultValue;
            }
            return nValue;
        }

        public static double ConvertStringToDouble(string psValue)
        {
            return ConvertStringToDouble(psValue, (double)0.0);
        }

        public static double ConvertStringToDouble(string psValue, double pnDefaultValue)
        {
            double nValue = (double)0.0;
            try
            {
                nValue = Convert.ToDouble(psValue);
            }
            catch
            {
                nValue = pnDefaultValue;
            }
            return nValue;
        }

        public static DateTime ConvertStringToDateTime(string psValue, string psDefaultValue)
        {
            DateTime dValue;
            DateTime dDefaultValue;
            try
            {
                if (DateTime.TryParse(psDefaultValue, out dDefaultValue) == false)
                    dDefaultValue = DateTime.MinValue;
            }
            catch
            {
                dDefaultValue = DateTime.MinValue;
            }

            try
            {
                if (DateTime.TryParse(psValue, out dValue) == false)
                    dValue = dDefaultValue;
            }
            catch
            {
                dValue = dDefaultValue;
            }

            return dValue;
        }

        public static DateTime ConvertStringToDateTime(string psValue, DateTime pdDefaultValue)
        {
            DateTime dValue;

            try
            {
                if (DateTime.TryParse(psValue, out dValue) == false)
                    dValue = pdDefaultValue;
            }
            catch
            {
                dValue = pdDefaultValue;
            }

            return dValue;
        }

        public static TimeSpan ConvertStringToTimeSpan(string psValue, string psDefaultValue)
        {
            TimeSpan tsValue;
            TimeSpan tsDefaultValue;
            try
            {
                if (TimeSpan.TryParse(psDefaultValue, out tsDefaultValue) == false)
                    tsDefaultValue = TimeSpan.MinValue;
            }
            catch
            {
                tsDefaultValue = TimeSpan.MinValue;
            }

            try
            {
                if (TimeSpan.TryParse(psValue, out tsValue) == false)
                    tsValue = tsDefaultValue;
            }
            catch
            {
                tsValue = tsDefaultValue;
            }

            return tsValue;
        }

        public static TimeSpan ConvertStringToTimeSpan(string psValue, TimeSpan tsDefaultValue)
        {
            TimeSpan tsValue;

            try
            {
                if (TimeSpan.TryParse(psValue, out tsValue) == false)
                    tsValue = tsDefaultValue;
            }
            catch
            {
                tsValue = tsDefaultValue;
            }

            return tsValue;
        }

        public static int StringLength(string psStringValue)
        {
            int nLen = 0;
            if (String.IsNullOrEmpty(psStringValue))
                nLen = 0;
            else
                nLen = psStringValue.Length;
            return nLen;
        }

        public static string ReverseString(string psStringValue)
        {

            char[] rev = psStringValue.ToCharArray();
            Array.Reverse(rev);
            return (new string(rev));

        }

        public static byte[] ConvertStringToByteArray(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }

        public static string ConvertByteArrayToString(byte[] bytes)
        {
            char[] chars = new char[bytes.Length / sizeof(char)];
            System.Buffer.BlockCopy(bytes, 0, chars, 0, bytes.Length);
            return new string(chars);
        }

        public static string RepeatChar(char c, int count)
        {
            return new string(c, count);
        }

        public static string ConvertCharArrayToString(char[] chars)
        {
            return new String(chars);
        }

        public static string ConvertCharToString(char ch)
        {
            return new String(ch, 1);
        }

    }
}
