﻿namespace TestprogLoggerLiabraryDevonCode
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cmdExit = new System.Windows.Forms.Button();
            this.cmdRunTest = new System.Windows.Forms.Button();
            this.cmdResetForm = new System.Windows.Forms.Button();
            this.mainFormToolTips = new System.Windows.Forms.ToolTip(this.components);
            this.lblMaxNumGetSum = new System.Windows.Forms.Label();
            this.lblMinNumGetSum = new System.Windows.Forms.Label();
            this.txtMinNumGetSum = new System.Windows.Forms.TextBox();
            this.txtMaxNumGetSum = new System.Windows.Forms.TextBox();
            this.lblOutputInterval = new System.Windows.Forms.Label();
            this.chkShowDateTimeInOutput = new System.Windows.Forms.CheckBox();
            this.txtOutputInterval = new System.Windows.Forms.TextBox();
            this.grpMessageDefinition = new System.Windows.Forms.GroupBox();
            this.optOutputMessagesToTextLogFile = new System.Windows.Forms.RadioButton();
            this.txtTextLogFilePath = new System.Windows.Forms.TextBox();
            this.chkAppendMessagesIfFileExists = new System.Windows.Forms.CheckBox();
            this.chkShowApplicationNameWithEachMessage = new System.Windows.Forms.CheckBox();
            this.chkShowMessageTypeWithEachMessage = new System.Windows.Forms.CheckBox();
            this.chkShowMachineNameWithEachMessage = new System.Windows.Forms.CheckBox();
            this.grpTextLogFileParameters = new System.Windows.Forms.GroupBox();
            this.panelCommandButtons = new System.Windows.Forms.Panel();
            this.grpMessageDefinition.SuspendLayout();
            this.grpTextLogFileParameters.SuspendLayout();
            this.panelCommandButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdExit
            // 
            this.cmdExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdExit.Location = new System.Drawing.Point(28, 202);
            this.cmdExit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmdExit.Name = "cmdExit";
            this.cmdExit.Size = new System.Drawing.Size(124, 46);
            this.cmdExit.TabIndex = 0;
            this.cmdExit.Text = "E&xit";
            this.cmdExit.UseVisualStyleBackColor = true;
            this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
            // 
            // cmdRunTest
            // 
            this.cmdRunTest.Location = new System.Drawing.Point(28, 18);
            this.cmdRunTest.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmdRunTest.Name = "cmdRunTest";
            this.cmdRunTest.Size = new System.Drawing.Size(124, 46);
            this.cmdRunTest.TabIndex = 1;
            this.cmdRunTest.Text = "&Run Test";
            this.cmdRunTest.UseVisualStyleBackColor = true;
            this.cmdRunTest.Click += new System.EventHandler(this.cmdRunTest_Click);
            // 
            // cmdResetForm
            // 
            this.cmdResetForm.Location = new System.Drawing.Point(28, 154);
            this.cmdResetForm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmdResetForm.Name = "cmdResetForm";
            this.cmdResetForm.Size = new System.Drawing.Size(124, 28);
            this.cmdResetForm.TabIndex = 2;
            this.cmdResetForm.Text = "Reset Form";
            this.mainFormToolTips.SetToolTip(this.cmdResetForm, "Restores form to its default screen position and size");
            this.cmdResetForm.UseVisualStyleBackColor = true;
            this.cmdResetForm.Click += new System.EventHandler(this.cmdResetForm_Click);
            // 
            // lblMaxNumGetSum
            // 
            this.lblMaxNumGetSum.AutoSize = true;
            this.lblMaxNumGetSum.Location = new System.Drawing.Point(31, 64);
            this.lblMaxNumGetSum.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMaxNumGetSum.Name = "lblMaxNumGetSum";
            this.lblMaxNumGetSum.Size = new System.Drawing.Size(240, 17);
            this.lblMaxNumGetSum.TabIndex = 4;
            this.lblMaxNumGetSum.Text = "Max Number for Get Sum Calculation";
            // 
            // lblMinNumGetSum
            // 
            this.lblMinNumGetSum.AutoSize = true;
            this.lblMinNumGetSum.Location = new System.Drawing.Point(31, 33);
            this.lblMinNumGetSum.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMinNumGetSum.Name = "lblMinNumGetSum";
            this.lblMinNumGetSum.Size = new System.Drawing.Size(237, 17);
            this.lblMinNumGetSum.TabIndex = 5;
            this.lblMinNumGetSum.Text = "Min Number for Get Sum Calculation";
            // 
            // txtMinNumGetSum
            // 
            this.txtMinNumGetSum.Location = new System.Drawing.Point(301, 33);
            this.txtMinNumGetSum.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMinNumGetSum.Name = "txtMinNumGetSum";
            this.txtMinNumGetSum.Size = new System.Drawing.Size(75, 22);
            this.txtMinNumGetSum.TabIndex = 6;
            this.txtMinNumGetSum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMaxNumGetSum
            // 
            this.txtMaxNumGetSum.Location = new System.Drawing.Point(301, 66);
            this.txtMaxNumGetSum.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMaxNumGetSum.Name = "txtMaxNumGetSum";
            this.txtMaxNumGetSum.Size = new System.Drawing.Size(75, 22);
            this.txtMaxNumGetSum.TabIndex = 7;
            this.txtMaxNumGetSum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblOutputInterval
            // 
            this.lblOutputInterval.AutoSize = true;
            this.lblOutputInterval.Location = new System.Drawing.Point(31, 92);
            this.lblOutputInterval.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOutputInterval.Name = "lblOutputInterval";
            this.lblOutputInterval.Size = new System.Drawing.Size(101, 17);
            this.lblOutputInterval.TabIndex = 8;
            this.lblOutputInterval.Text = "Output Interval";
            // 
            // chkShowDateTimeInOutput
            // 
            this.chkShowDateTimeInOutput.AutoSize = true;
            this.chkShowDateTimeInOutput.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkShowDateTimeInOutput.Location = new System.Drawing.Point(31, 123);
            this.chkShowDateTimeInOutput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkShowDateTimeInOutput.Name = "chkShowDateTimeInOutput";
            this.chkShowDateTimeInOutput.Size = new System.Drawing.Size(195, 21);
            this.chkShowDateTimeInOutput.TabIndex = 9;
            this.chkShowDateTimeInOutput.Text = "Show Date/Time in Output";
            this.chkShowDateTimeInOutput.UseVisualStyleBackColor = true;
            // 
            // txtOutputInterval
            // 
            this.txtOutputInterval.Location = new System.Drawing.Point(215, 92);
            this.txtOutputInterval.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtOutputInterval.Name = "txtOutputInterval";
            this.txtOutputInterval.Size = new System.Drawing.Size(85, 22);
            this.txtOutputInterval.TabIndex = 10;
            // 
            // grpMessageDefinition
            // 
            this.grpMessageDefinition.Controls.Add(this.lblMaxNumGetSum);
            this.grpMessageDefinition.Controls.Add(this.lblMinNumGetSum);
            this.grpMessageDefinition.Controls.Add(this.txtMinNumGetSum);
            this.grpMessageDefinition.Controls.Add(this.txtMaxNumGetSum);
            this.grpMessageDefinition.Controls.Add(this.txtOutputInterval);
            this.grpMessageDefinition.Controls.Add(this.lblOutputInterval);
            this.grpMessageDefinition.Controls.Add(this.chkShowDateTimeInOutput);
            this.grpMessageDefinition.Location = new System.Drawing.Point(37, 42);
            this.grpMessageDefinition.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpMessageDefinition.Name = "grpMessageDefinition";
            this.grpMessageDefinition.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpMessageDefinition.Size = new System.Drawing.Size(449, 166);
            this.grpMessageDefinition.TabIndex = 14;
            this.grpMessageDefinition.TabStop = false;
            this.grpMessageDefinition.Text = "Message Definition";
            // 
            // optOutputMessagesToTextLogFile
            // 
            this.optOutputMessagesToTextLogFile.AutoSize = true;
            this.optOutputMessagesToTextLogFile.Location = new System.Drawing.Point(37, 216);
            this.optOutputMessagesToTextLogFile.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.optOutputMessagesToTextLogFile.Name = "optOutputMessagesToTextLogFile";
            this.optOutputMessagesToTextLogFile.Size = new System.Drawing.Size(241, 21);
            this.optOutputMessagesToTextLogFile.TabIndex = 17;
            this.optOutputMessagesToTextLogFile.TabStop = true;
            this.optOutputMessagesToTextLogFile.Text = "Output Messages to Text Log File";
            this.optOutputMessagesToTextLogFile.UseVisualStyleBackColor = true;
            // 
            // txtTextLogFilePath
            // 
            this.txtTextLogFilePath.Location = new System.Drawing.Point(37, 245);
            this.txtTextLogFilePath.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTextLogFilePath.Name = "txtTextLogFilePath";
            this.txtTextLogFilePath.Size = new System.Drawing.Size(449, 22);
            this.txtTextLogFilePath.TabIndex = 18;
            // 
            // chkAppendMessagesIfFileExists
            // 
            this.chkAppendMessagesIfFileExists.AutoSize = true;
            this.chkAppendMessagesIfFileExists.Location = new System.Drawing.Point(13, 28);
            this.chkAppendMessagesIfFileExists.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkAppendMessagesIfFileExists.Name = "chkAppendMessagesIfFileExists";
            this.chkAppendMessagesIfFileExists.Size = new System.Drawing.Size(224, 21);
            this.chkAppendMessagesIfFileExists.TabIndex = 19;
            this.chkAppendMessagesIfFileExists.Text = "Append Messages if File Exists";
            this.chkAppendMessagesIfFileExists.UseVisualStyleBackColor = true;
            // 
            // chkShowApplicationNameWithEachMessage
            // 
            this.chkShowApplicationNameWithEachMessage.AutoSize = true;
            this.chkShowApplicationNameWithEachMessage.Location = new System.Drawing.Point(13, 85);
            this.chkShowApplicationNameWithEachMessage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkShowApplicationNameWithEachMessage.Name = "chkShowApplicationNameWithEachMessage";
            this.chkShowApplicationNameWithEachMessage.Size = new System.Drawing.Size(303, 21);
            this.chkShowApplicationNameWithEachMessage.TabIndex = 20;
            this.chkShowApplicationNameWithEachMessage.Text = "Show Application Name with Each Message";
            this.chkShowApplicationNameWithEachMessage.UseVisualStyleBackColor = true;
            // 
            // chkShowMessageTypeWithEachMessage
            // 
            this.chkShowMessageTypeWithEachMessage.AutoSize = true;
            this.chkShowMessageTypeWithEachMessage.Location = new System.Drawing.Point(13, 57);
            this.chkShowMessageTypeWithEachMessage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkShowMessageTypeWithEachMessage.Name = "chkShowMessageTypeWithEachMessage";
            this.chkShowMessageTypeWithEachMessage.Size = new System.Drawing.Size(286, 21);
            this.chkShowMessageTypeWithEachMessage.TabIndex = 21;
            this.chkShowMessageTypeWithEachMessage.Text = "Show Message Type with Each Message";
            this.chkShowMessageTypeWithEachMessage.UseVisualStyleBackColor = true;
            // 
            // chkShowMachineNameWithEachMessage
            // 
            this.chkShowMachineNameWithEachMessage.AutoSize = true;
            this.chkShowMachineNameWithEachMessage.Location = new System.Drawing.Point(13, 114);
            this.chkShowMachineNameWithEachMessage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkShowMachineNameWithEachMessage.Name = "chkShowMachineNameWithEachMessage";
            this.chkShowMachineNameWithEachMessage.Size = new System.Drawing.Size(287, 21);
            this.chkShowMachineNameWithEachMessage.TabIndex = 22;
            this.chkShowMachineNameWithEachMessage.Text = "Show Machine Name with Each Message";
            this.chkShowMachineNameWithEachMessage.UseVisualStyleBackColor = true;
            // 
            // grpTextLogFileParameters
            // 
            this.grpTextLogFileParameters.Controls.Add(this.chkShowMachineNameWithEachMessage);
            this.grpTextLogFileParameters.Controls.Add(this.chkAppendMessagesIfFileExists);
            this.grpTextLogFileParameters.Controls.Add(this.chkShowMessageTypeWithEachMessage);
            this.grpTextLogFileParameters.Controls.Add(this.chkShowApplicationNameWithEachMessage);
            this.grpTextLogFileParameters.Location = new System.Drawing.Point(37, 275);
            this.grpTextLogFileParameters.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpTextLogFileParameters.Name = "grpTextLogFileParameters";
            this.grpTextLogFileParameters.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpTextLogFileParameters.Size = new System.Drawing.Size(449, 155);
            this.grpTextLogFileParameters.TabIndex = 23;
            this.grpTextLogFileParameters.TabStop = false;
            this.grpTextLogFileParameters.Text = "Text Log File Parameters";
            // 
            // panelCommandButtons
            // 
            this.panelCommandButtons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelCommandButtons.Controls.Add(this.cmdRunTest);
            this.panelCommandButtons.Controls.Add(this.cmdResetForm);
            this.panelCommandButtons.Controls.Add(this.cmdExit);
            this.panelCommandButtons.Location = new System.Drawing.Point(494, 42);
            this.panelCommandButtons.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelCommandButtons.Name = "panelCommandButtons";
            this.panelCommandButtons.Size = new System.Drawing.Size(179, 388);
            this.panelCommandButtons.TabIndex = 26;
            // 
            // MainForm
            // 
            this.AcceptButton = this.cmdRunTest;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cmdExit;
            this.ClientSize = new System.Drawing.Size(689, 444);
            this.Controls.Add(this.panelCommandButtons);
            this.Controls.Add(this.grpTextLogFileParameters);
            this.Controls.Add(this.txtTextLogFilePath);
            this.Controls.Add(this.optOutputMessagesToTextLogFile);
            this.Controls.Add(this.grpMessageDefinition);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Form";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.grpMessageDefinition.ResumeLayout(false);
            this.grpMessageDefinition.PerformLayout();
            this.grpTextLogFileParameters.ResumeLayout(false);
            this.grpTextLogFileParameters.PerformLayout();
            this.panelCommandButtons.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdExit;
        private System.Windows.Forms.Button cmdRunTest;
        private System.Windows.Forms.Button cmdResetForm;
        private System.Windows.Forms.ToolTip mainFormToolTips;
        private System.Windows.Forms.Label lblMaxNumGetSum;
        private System.Windows.Forms.Label lblMinNumGetSum;
        private System.Windows.Forms.TextBox txtMinNumGetSum;
        private System.Windows.Forms.TextBox txtMaxNumGetSum;
        private System.Windows.Forms.Label lblOutputInterval;
        private System.Windows.Forms.CheckBox chkShowDateTimeInOutput;
        private System.Windows.Forms.TextBox txtOutputInterval;
        private System.Windows.Forms.GroupBox grpMessageDefinition;
        private System.Windows.Forms.RadioButton optOutputMessagesToTextLogFile;
        private System.Windows.Forms.TextBox txtTextLogFilePath;
        private System.Windows.Forms.CheckBox chkAppendMessagesIfFileExists;
        private System.Windows.Forms.CheckBox chkShowApplicationNameWithEachMessage;
        private System.Windows.Forms.CheckBox chkShowMessageTypeWithEachMessage;
        private System.Windows.Forms.CheckBox chkShowMachineNameWithEachMessage;
        private System.Windows.Forms.GroupBox grpTextLogFileParameters;
        private System.Windows.Forms.Panel panelCommandButtons;
    }
}

