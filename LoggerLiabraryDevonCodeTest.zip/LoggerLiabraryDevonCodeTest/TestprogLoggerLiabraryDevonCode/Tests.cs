﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GlobalObjects;
using System.IO;
using LoggerLiabraryDevonCodeTest;
using TestMessageLogDLL;

namespace TestprogLoggerLiabraryDevonCode
{
    public class Tests
    {
        private StringBuilder _msg = new StringBuilder();
        private StringBuilder _str = new StringBuilder();
        private bool _saveErrorMessagesToAppLog = false;
        MessageLog _messageLog = null;
        TestMessageLogClass _testClass = new TestMessageLogClass();

        //properties
        public bool SaveErrorMessagesToAppLog
        {
            get
            {
                return this._saveErrorMessagesToAppLog;
            }
            set
            {
                this._saveErrorMessagesToAppLog = value;
            }
        }

        public MessageLog MessageLog
        {
            get
            {
                return _messageLog;
            }
            set
            {
                _messageLog = value;
            }
        }

        //tests
        public void RunApplicationMessageLogTest(long minNum, long maxNum, long outputEveryInterval, bool showDateTime)
        {
            long sum = 0;

            try
            {
                if (_messageLog == null)
                {
                    throw new System.Exception("MessageLog object must be defined in order to run GetSum in Tests module.");
                }

                sum = this.GetSum(minNum, maxNum, outputEveryInterval, showDateTime);
                WriteMessageToLog(Environment.NewLine);
                _msg.Length = 0;
                _msg.Append("Sum = ");
                _msg.Append(sum.ToString("#,##0"));
                WriteMessageToLog(_msg.ToString());
                WriteMessageToLog(Environment.NewLine);
            }
            catch (System.Exception ex)
            {
                _msg.Length = 0;
                _msg.Append(GlobalObjects.AppMessages.FormatErrorMessage(ex));
                WriteMessageToLog(_msg.ToString());
                AppMessages.DisplayErrorMessage(_msg.ToString(), _saveErrorMessagesToAppLog);
            }
            finally
            {
                ;
            }
                 
        
        }

        private long GetSum(long minNum, long maxNum, long outputEveryInterval, bool showDateTime)
        {
            long sum = 0;

            try
            {
                _messageLog.Clear();
                _messageLog.ShowDatetime = showDateTime;
                _messageLog.WriteLine("Running GetSum routine ...");
                _messageLog.ShowWindow();
                for (long i = minNum; i <= maxNum; i++)
                {
                    sum += i;
                    if ((i % outputEveryInterval) == 0 || i == maxNum)
                    {
                        _msg.Length = 0;
                        _msg.Append("Sum calculated to " + i.ToString("#,##0"));
                        _msg.Append(" = ");
                        _msg.Append(sum.ToString("#,##0"));
                        WriteMessageToLog(_msg.ToString());
                    }
                }
            }
            catch (System.Exception ex)
            {
                _msg.Length = 0;
                _msg.Append(GlobalObjects.AppMessages.FormatErrorMessage(ex));
                WriteMessageToLog(_msg.ToString());
                AppMessages.DisplayErrorMessage(_msg.ToString());
            }
            finally
            {
                ;
            }

            return sum;
        }

        public void RunDllGetSumTest(long minNum, long maxNum, long outputEveryInterval, bool showDateTime)
        {
            long sum = 0;

            try
            {
                sum = _testClass.GetSum(minNum, maxNum, outputEveryInterval, showDateTime);
                _msg.Length = 0;
                _msg.Append("Sum = ");
                _msg.Append(sum.ToString("#,##0"));
                WriteMessageToLog(_msg.ToString());
            }
            catch (System.Exception ex)
            {
                _msg.Length = 0;
                _msg.Append(GlobalObjects.AppMessages.FormatErrorMessage(ex));
                WriteMessageToLog(_msg.ToString());
                AppMessages.DisplayErrorMessage(_msg.ToString(), _saveErrorMessagesToAppLog);
            }
            finally
            {
                ;
            }
        
        }

        public void ShowDllWindow()
        {
            _testClass.ShowMessageLog();
        }

        public void HideDllWindow()
        {
            _testClass.HideMessageLog();
        }


        public void OutputMessagesToTextLogFile(string outputFilename, bool appendMessagesIfFileExists,
                                                bool showMessageType, bool showApplicationName, bool showMachineName,
                                                long minNum, long maxNum, long outputEveryInterval, bool showDateTime)
        {
            long sum = 0;

            try
            {
                _msg.Length = 0;
                _msg.Append("Outputting messages to ");
                _msg.Append(outputFilename);
                WriteMessageToLog(_msg.ToString());

                sum = GetSumToOutputFile(outputFilename, appendMessagesIfFileExists, 
                                         showMessageType, showApplicationName, showMachineName,
                                         minNum, maxNum, outputEveryInterval, showDateTime);

                _msg.Length = 0;
                _msg.Append("Sum = ");
                _msg.Append(sum.ToString("#,##0"));
                WriteMessageToLog(_msg.ToString());

                System.Diagnostics.Process.Start("notepad.exe", outputFilename);

            }
            catch (System.Exception ex)
            {
                _msg.Length = 0;
                _msg.Append(GlobalObjects.AppMessages.FormatErrorMessage(ex));
                WriteMessageToLog(_msg.ToString());
                AppMessages.DisplayErrorMessage(_msg.ToString());
            }
            finally
            {
                _msg.Length = 0;
                _msg.Append("Output messages to file test finished.");
                WriteMessageToLog(_msg.ToString());
            }
                 
        
        }

        private long GetSumToOutputFile(string outputFilename, bool appendMessagesIfFileExists, 
                                        bool showMessageType, bool showApplicationName, bool showMachineName,
                                        long minNum, long maxNum, long outputEveryInterval, bool showDateTime)
        {
            long sum = 0;
            TextLogFile logfile = null;

            try
            {
                logfile = new TextLogFile(outputFilename);
                logfile.ShowMessageType = showMessageType;
                if(showApplicationName)
                {
                    logfile.ApplicationName = "TestprogMessageLogs";
                }
                if(showMachineName)
                {
                    logfile.MachineName = Environment.MachineName;
                }
                if(File.Exists(outputFilename))
                {
                    if(appendMessagesIfFileExists == false)
                    {
                        logfile.TruncateFile();
                    }
                }

                logfile.ShowDatetime = showDateTime;
                for (long i = minNum; i <= maxNum; i++)
                {
                    sum += i;
                    if ((i % outputEveryInterval) == 0 || i == maxNum)
                    {
                        _msg.Length = 0;
                        _msg.Append("Sum calculated to " + i.ToString("#,##0"));
                        _msg.Append(" = ");
                        _msg.Append(sum.ToString("#,##0"));
                        logfile.WriteLine(_msg.ToString(), TextLogFile.LogMessageType.Information);
                    }
                }
                if (showMessageType)
                {
                    logfile.WriteLine("This is a test warning message.", TextLogFile.LogMessageType.Warning);
                    logfile.WriteLine("This is a test error message.", TextLogFile.LogMessageType.Error);
                }
            }
            catch (System.Exception ex)
            {
                _msg.Length = 0;
                _msg.Append(GlobalObjects.AppMessages.FormatErrorMessage(ex));
                logfile.WriteLine(_msg.ToString(), TextLogFile.LogMessageType.Error);
                WriteMessageToLog(_msg.ToString());
                AppMessages.DisplayErrorMessage(_msg.ToString());
            }
            finally
            {
                ;
            }

            return sum;
        }
        
        public void WriteMessageToLog(string msg)
        {
            if (_messageLog != null)
                _messageLog.WriteLine(msg);
        }




    }//end class
}//end namespace
