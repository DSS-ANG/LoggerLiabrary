﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Threading;
using GlobalObjects;
using LoggerLiabraryDevonCodeTest;

namespace TestprogLoggerLiabraryDevonCode
{
    static class Program
    {
        public static MainForm _mainForm;
        public static MessageLog _messageLog;

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            CAppGlobalErrorHandler.WriteToAppLog = true;
            CAppGlobalErrorHandler.WriteToEventLog = false;
            CAppGlobalErrorHandler.CancelApplicationOnGlobalError = false;

            Application.ThreadException += new ThreadExceptionEventHandler(CAppGlobalErrorHandler.GlobalErrorHandler);

            _messageLog = new MessageLog();
            _messageLog.Caption = "Application Message Log for TestprogMessageLogs";
            _messageLog.ShowDatetime = false;
            _messageLog.ShowWindow();


            _mainForm = new MainForm();

            Application.Run(_mainForm);


        }
    }//end class
}//end namespace
